# 👨‍🎓 Education

`2010-2015` [National University of Computer and Emerging Sciences](https://www.nu.edu.pk/)
- **BSCS** in Computer Science.
- Courses: Datastructures, Databases, Datamining, Computer networks, Computer Organization, Discrete Mathematics, Object-Oriented Programming, Probability, Digital Logic Design
