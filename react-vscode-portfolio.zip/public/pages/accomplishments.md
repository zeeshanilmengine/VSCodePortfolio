# 🏆 Accomplishments
**Payment Integrations** @ [Moneygram](https://www.moneygram.com/) _(May 2021)_
Succesful implementation and deployment of moneygram remittance payment software with several banks and money exchanges.