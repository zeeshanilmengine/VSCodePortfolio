# 💻 Skills

## General Tech Stacks
- Mobile App Development
- Desktop App Development
- Web Development (Frontend & Backend)

## Programming languages
- C# .NET
- JavaScript(Node.js, React.js, Express.js)
- SQL
- Java,XML
- HTML, CSS (Bootstrap, Tailwind)

## Databases
- MSSQL
- Mongodb
- MySQL
- SQLite

## Cloud
- Azure
- AWS

## Vcs
- Git, Github