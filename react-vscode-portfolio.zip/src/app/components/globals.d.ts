declare module '*.md';
